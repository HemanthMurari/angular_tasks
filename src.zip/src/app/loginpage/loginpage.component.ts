import { Component } from '@angular/core';

@Component({
  selector: 'app-loginpage',
  templateUrl: './loginpage.component.html',
  styleUrls: ['./loginpage.component.css']
})
export class LoginpageComponent {
  email:string="";
  password:string="";
  error?:string;
  status:boolean=false;
 
  // Register Variables
 
  rusername:string="";
  rpassword:string="";
  vpassword:string="";
  remail:string="";
  rerror?:string;
  rstatus:boolean=false
 
 // Common variables
 
   logform:boolean=true;
   
  constructor(){ }

  ngOnInit(): void {
  }


  toggle(){
    this.logform=this.logform?false:true;
 }
 register():void{
  alert("Called");
   this.rerror="";
   let emailregex:RegExp=/^[a-z][a-z0-9_\.]+@[a-z]{2,5}\.[a-z]{3,5}$/


   if(this.rusername.length==0 || this.rpassword.length==0 || this.vpassword.length==0 )
   this.rerror="Fill all the fields";

   else if(this.rusername.length<4)
   this.rerror="Username should be atleast 4 charectars long"

   else if(this.rpassword.length<6)
   this.rerror="password should be atleast 6 charectars long"

   else if(this.rpassword!=this.vpassword)
   this.rerror="Username and password should match"
   
   else if(!emailregex.test(this.remail))
   this.rerror="not in email format"

  
   else{
       this.rstatus=true;
     
                this.rstatus=true;
                let obj={username:this.rusername,password:this.rpassword,type:"user",email: this.remail}
                
        
   }

}
}
